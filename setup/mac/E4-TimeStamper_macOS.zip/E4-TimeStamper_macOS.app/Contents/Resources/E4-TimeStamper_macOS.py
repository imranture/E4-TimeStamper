# ==================================================================
# ==================================================================
# E4 TimeStamper v0.1 (Beta)
# @author: Imran Ture (https://www.imranture.com/)
# platform: macOS
# built on 9 January 2021
# licensed under GNU General Public License v3.0
# For more details: https://imranture.com/E4-TimeStamper
# ==================================================================
# ==================================================================

# Changelog
# v0.2-beta - 2022-10-10
# Changed
#

# import libraries
import os
import numpy as np
import pandas as pd
from zipfile import ZipFile
from datetime import datetime
import pytz
from tkinter import *
from tkinter.ttk import Combobox
from tkinter.ttk import Progressbar, Style
from tkinter import filedialog
import webbrowser
from tkinter import messagebox
from PIL import Image, ImageTk
from threading import Thread
from queue import Queue
from time import sleep

# ==================================================================
# Main Class
# ==================================================================
# create E4_TimeStamper class
class E4_TimeStamper():

	# define initialization function
	def __init__(self):
		# create instance
		self.win = Tk()
		self.win.title('E4 TimeStamper 1987'.translate(str.maketrans('1987', 'ᴮᵉᵗᵃ')))
		self.win.iconbitmap('img/icon.ico')

		# self.win.iconbitmap(r'icon.ico')

		self.win.geometry('460x560')
		self.win.minsize(500, 500)
		self.win.resizable(width = False, height = False)
		self.win.config(background = '#638288')

		# create widgets
		self.create_widgets()

	# create queue instance
	def use_queues(self):
		gui_queue = Queue()
		print(gui_queue)

	# define a function to add timestamps for each physiological signal based on preferred timezone
	def timestamper(self):

		# create 'running...' progress
		self.runner.pack_forget()
		self.bottombar.pack_forget()
		self.statusbar.pack(side = BOTTOM, fill = X)

		# check if the user added any file(s)
		try:
			print(selected_files)
		except NameError:
			self.statusbar.pack_forget()
			self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
			self.bottombar.pack(side = BOTTOM, fill = X)
			raise self.no_files_warning()

		if not selected_files:
			self.statusbar.pack_forget()
			self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
			self.bottombar.pack(side = BOTTOM, fill = X)
			raise self.no_files_warning()

		# check if selected file(s) already exists
		for folder in selected_files:
			for root, dirs, files in os.walk(folder.rsplit('/', 1)[0], topdown = False):
				for name in dirs:
					if name == folder.split('/')[-1].split('.')[0]:
						global folder_exists
						folder_exists = 'A folder with the name ' + folder.split('/')[-1].split('.')[0] + ' already exists.'
						self.statusbar.pack_forget()
						self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
						self.bottombar.pack(side = BOTTOM, fill = X)
						raise self.folder_already_exists_warning()

		# check if the user selected any timezone
		timezone = self.combo_timezone.get()
		if len(timezone) == 0:
			self.statusbar.pack_forget()
			self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
			self.bottombar.pack(side = BOTTOM, fill = X)
			raise self.timezone_missing_warning()

		# check if the user entered any date and time format
		datetimeformat = str(self.combo_datetime.get())
		print(datetimeformat)
		print(type(datetimeformat))
		if not datetimeformat:
			self.statusbar.pack_forget()
			self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
			self.bottombar.pack(side = BOTTOM, fill = X)
			raise self.datetime_missing_warning()

		# check if the user enter date and time format correctly
		# from dateutil.parser import parse
		# sample_datetime = '2020 04 13 10:30:10.000'
		# try:
		# 	datetime.strftime(parse(sample_datetime), datetimeformat)
		# except ValueError:
		# 	self.statusbar.pack_forget()
		# 	self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
		# 	self.bottombar.pack(side = BOTTOM, fill = X)
		# 	raise self.datetime_formaterror_warning()

		# unzipped each selected file
		start_time = datetime.now()
		print('Start =', start_time.time().strftime('%H:%M:%S'))
		for folder in selected_files:
			os.chdir(os.path.dirname(folder))
			name_of_folder = folder.split('/')[-1].split('.')[0]
			os.mkdir(name_of_folder)
			# if not os.path.exists('/name_of_folder'):
			#	os.mkdir(name_of_folder)
			unzipped_folder = ZipFile(folder, 'r')
			unzipped_folder.extractall(name_of_folder)

			os.chdir(name_of_folder)
			list_of_files = os.listdir(os.getcwd())

			self.progress_bar['maximum'] = 6
			# add timestamps for each E4 files
			self.progress_bar['value'] = 1
			self.progress_bar.update()  # have to call update() in loop

			for file in list_of_files:
				if (file != 'info.txt') and (file != 'tags.csv'):
					fileOpened = open(file)
					# print(f"\nRead {file}... {datetime.now().time().strftime('%H:%M:%S')}")
					series = pd.read_csv(fileOpened, header = None, index_col = False, parse_dates = False, squeeze = True)
					series = np.array(series)

					# check how to initialize time and frequency settings based on the type of physiological signal
					try:
						if series.shape[1] > 0:
							initial_time = series[0][0]
							freq = series[1][0]
					except Exception:
						initial_time = series[0]
						freq = series[1]

					unix_time = []
					if (file == 'IBI.csv'):
						for j in range(0, len(series) - 1):
							unix_time.append(initial_time + series[j + 1][0])
					else:
						for j in range(0, len(series) - 2):
							unix_time.append((j / freq) + initial_time)

					# print(f"Get timestamps... {datetime.now().time().strftime('%H:%M:%S')}")
					timestamps = []
					for t in range(0, len(series) - 2):
						timestamps.append(datetime.utcfromtimestamp(unix_time[t]))

					timestamps = pd.Series(pd.DatetimeIndex(timestamps[0:]).tz_localize('UTC').tz_convert(timezone).strftime(datetimeformat))

					# print(f"Get {file} signals... {datetime.now().time().strftime('%H:%M:%S')}")
					if (file == 'IBI.csv'):
						signals = pd.DataFrame(series[1:, 1])
					else:
						signals = pd.DataFrame(series[2:])
					signals.reset_index(drop = True, inplace = True)

					data = pd.concat([timestamps, signals], axis = 1)
					# print(f"Create new {file} with timestamps added (and delete the old one)... {datetime.now().time().strftime('%H:%M:%S')}")
					data.to_csv(file, index = False, header = False, )
					# print('Done!')
					#fileOpened.close()
					self.progress_bar['value'] = self.progress_bar['value'] +1  # increment progressbar
					self.progress_bar.update()  # have to call update() in loop

				else:
					continue
		# os.chdir('..')
		self.statusbar.pack_forget()
		self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 1, anchor = 'center')
		self.bottombar.pack(side = BOTTOM, fill = X)
		end_time = datetime.now()
		print('\nStop =', end_time.time().strftime('%H:%M:%S'))
		duration = ((end_time - start_time).seconds // 60) % 60
		print('Time spent =', str(duration), 'minutes')
		# call a task completed warning and close the window
		self.task_completed_warning()

	# define a function to create threads
	def create_thread(self):
		self.run_thread = Thread(target = self.timestamper)
		self.run_thread.setDaemon(True)  # <== RuntimeError: main thread is not in main loop
		self.run_thread.start()
		# print(self.run_thread)
		# print('createThread():', self.run_thread.isAlive())

		# start queue in its own thread
		write_thread = Thread(target = self.use_queues, daemon = True)
		write_thread.start()

	# define a button that can create threads
	def click_me(self):
		self.create_thread()
		# self.timestamper()

	# define a function to select files
	def open_file(self):
		global selected_files
		selected_files = filedialog.askopenfilenames(initialdir = '/', title = 'Select E4 zip file(s)', filetypes = (('zip files', '*.zip'),))
		global lst
		lst = []
		self.listbox.delete(0, 'end')
		for i in selected_files:
			lst.append(i.split('/')[-1])
		for i in lst:
			self.listbox.insert(END, str(i))

	# define web links
	def weblink1(self):
		webbrowser.open_new('https://www.imranture.com/page/E4-TimeStamper')

	def weblink2(self):
		webbrowser.open_new('https://www.empatica.com/research/e4/')

	def weblink3(self):
		webbrowser.open_new('https://devhints.io/datetime')

	def weblink4(self):
		webbrowser.open_new('https://www.timeanddate.com/time/map/')

	def weblink5(self):
		webbrowser.open_new('https://www.buymeacoffee.com/imran')

	# define warnings
	def task_completed_warning(self):
		messagebox.showinfo('Warning', 'Task completed!\nFolder(s) containing E4 Files with timestamps are created within the same directory with your selected E4 zip file(s).')
		# self.win.destroy()

	def no_files_warning(self):
		messagebox.showinfo('Warning', 'No file(s) added!')

	def timezone_missing_warning(self):
		messagebox.showinfo('Warning', 'Timezone is missing!')

	def datetime_missing_warning(self):
		messagebox.showinfo('Warning', 'Datetime format is not missing!')

	def datetime_formaterror_warning(self):
		messagebox.showinfo('Warning', 'Invalid datetime format!')

	def folder_already_exists_warning(self):
		messagebox.showinfo('Warning', folder_exists)

	# define about page section
	def create_about_page(self):
		self.about_window = Toplevel(self.win)
		self.about_window.title('')
		self.about_window.iconbitmap(r'img/noicon.ico')
		# self.about_window.iconbitmap(r'noicon.ico')
		# get the requested values of the height and widht
		windowWidth = self.about_window.winfo_reqwidth()
		windowHeight = self.about_window.winfo_reqheight()
		# get both half the screen width/height and window width/height
		positionRight = int(self.about_window.winfo_screenwidth() / 2 - windowWidth / 2)
		positionDown = int(self.about_window.winfo_screenheight() / 2 - windowHeight / 2)
		# position the window in the center of the page.
		self.about_window.geometry("+{}+{}".format(positionRight, positionDown))
		self.about_window.configure(bg = '#638288')
		# self.about_window.geometry('300x300')
		self.about_window.resizable(width = False, height = False)
		photo = ImageTk.PhotoImage(Image.open('img/icon.png'))
		# photo = ImageTk.PhotoImage(Image.open('icon.png'))
		self.about_page_photo = Label(self.about_window, image = photo, fg = 'black', bg = '#638288')
		self.about_page_photo.pack(ipadx = 0, ipady = 5, padx = 0, pady = 0, anchor = 'center')
		self.about_page_photo.image = photo
		self.about_page1 = Label(self.about_window,
								 text = 'E4 TimeStamper',
								 font = 'Calibri 15', fg = 'white', bg = '#638288')
		self.about_page2 = Label(self.about_window,
								 text = 'Copyright \u00A9 2020 Imran Ture',
								 font = 'Calibri 11', fg = 'white', bg = '#638288')
		self.about_page3 = Label(self.about_window,
								 text = 'v0.4 (Beta) - ### #, 2021 \nLicensed under the GNU General Public License v3.0\nPowered by Python',
								 font = 'Calibri 11', fg = 'white', bg = '#638288')
		self.about_page4 = Label(self.about_window,
								 text = 'E4 wristband is a medical-grade wearable device\ndeveloped by Empatica\n\nThe logo made by Freepik from Flaticon, www.flaticon.com\n',
								 font = 'Calibri 9', fg = 'white', bg = '#638288')
		self.about_page1.pack(ipadx = 20, ipady = 0, anchor = 'center')
		self.about_page2.pack(ipadx = 20, pady = (0, 5), anchor = 'center')
		self.about_page3.pack(ipadx = 20, ipady = 5, anchor = 'center')
		self.about_page4.pack(ipadx = 20, ipady = 5, anchor = 'center')

	# Add a Progressbar to Tab 2

	# update progressbar in callback loop
	def run_progressbar(self):
		# self.progress_bar["maximum"] = 20
		for i in range(21):
			sleep(10)
			self.progress_bar["value"] = i  # increment progressbar
			self.sty.configure("LabeledProgressbar", text = "{0} %      ".format(i))
			self.progress_bar.update()  # have to call update() in loop

	# self.progress_bar["value"] = 0  # reset/clear progressbar

	# create widgets, frames and menu bar
	def create_widgets(self):
		# create menu bar
		menubar = Menu(self.win)
		self.win.config(menu = menubar)

		# add help menu
		help_ = Menu(menubar, tearoff = 0)
		menubar.add_cascade(label = 'Help', menu = help_)
		help_.add_command(label = 'Visit E4 TimeStamper...', command = self.weblink1)
		help_.add_command(label = 'Learn more about E4 wristbands by Empatica...', command = self.weblink2)
		help_.add_command(label = 'Date & Time Formats Cheat Sheet', command = self.weblink3)
		help_.add_command(label = 'Time Zone Map', command = self.weblink4)
		help_.add_separator()
		help_.add_command(label = 'Do you like it? Support the developer...', command = self.weblink5)
		help_.add_separator()
		help_.add_command(label = 'About', command = self.create_about_page)

		# add first frame
		frame1 = LabelFrame(self.win, text = 'Step 1:   Select E4 zip file(s)', fg = '#e4ecec', font = 'Calibri  12', height = 175, width = 250, bg = '#638288', relief = FLAT)
		frame1.pack_propagate(0)
		frame1.pack(ipadx = 15, ipady = 5, padx = 15, pady = (30, 15), anchor = 'center')

		# create uploader button
		uploader = Button(frame1, text = 'Browse...', font = 'Calibri 12', command = self.open_file, height = 1, width = 50)
		uploader.pack(ipadx = 5, ipady = 10, padx = 15, pady = 15, anchor = 'center')

		# create a list box with scrollbar to show selected file(s)
		listlabel = Label(frame1, text = 'Selected file(s):', fg = '#e4ecec', font = 'Calibri  11', bg = '#638288', width = 30)
		listlabel.pack(side = TOP, anchor = 'w')
		scroll = Scrollbar(frame1, orient = 'vertical')
		scroll.pack(side = RIGHT, fill = Y)
		self.listbox = StringVar()
		self.listbox = Listbox(frame1, yscrollcommand = scroll.set, foreground = 'black', background = 'white', selectbackground = 'skyblue', height = 4, width = 27, relief = FLAT)
		self.listbox.bind('<B1-Leave>', lambda event:'break')
		self.listbox.pack(side = RIGHT)
		scroll.config(command = self.listbox.yview)

		# add second frame
		frame2 = LabelFrame(self.win, text = 'Step 2:   Choose (or type) timezone', fg = '#e4ecec', font = 'Calibri  12', height = 75, width = 250, bg = '#638288', relief = FLAT)
		frame2.pack_propagate(0)
		frame2.pack(ipadx = 15, ipady = 5, padx = 15, pady = (5, 5), anchor = 'center')

		# create combo boxes for timezones selection
		timezone_options = pytz.all_timezones
		self.combo_timezone = AutoCompleteCombobox(frame2, font = 'Calibri  11', foreground = 'black', background = 'white', width = 30)
		self.combo_timezone.set_completion_list(timezone_options)
		# self.combo_timezone.set('UTC')
		self.combo_timezone.pack(ipadx = 5, ipady = 5, padx = (5, 5), pady = 10, anchor = 'center')

		# add third frame
		frame3 = LabelFrame(self.win, text = 'Step 3:   Enter date and time formats', fg = '#e4ecec', font = 'Calibri  12', height = 75, width = 250, bg = '#638288', relief = FLAT)
		frame3.pack_propagate(0)
		frame3.pack(ipadx = 15, ipady = 5, padx = 15, pady = (5, 5), anchor = 'center')

		# create combo boxes for date & time format
		datetime_options = ['%d-%m-%Y %H:%M:%S.%f', '%d/%m/%Y %H:%M:%S.%f']
		self.combo_datetime = AutoCompleteCombobox(frame3, font = 'Calibri  11', width = 30)
		self.combo_datetime.set_completion_list(datetime_options)
		self.combo_datetime.pack(ipadx = 5, ipady = 5, padx = 15, pady = 10, anchor = 'center')

		# create entry for date & time format
		# self.entry_datetime = StringVar()
		# self.entry_datetime = Entry(frame3, font = 'Calibri  11', width = 33)
		# self.entry_datetime.insert(END, '%Y-%m-%d %H:%M:%S.%f')
		# self.entry_datetime.pack(ipadx = 5, ipady = 5, padx = 15, pady = 15, anchor = 'center')

		self.s = Style()
		self.s.theme_use('clam')
		self.s.configure("red.Horizontal.TProgressbar", foreground = '#DC143C', background = '#DC143C')

		self.progress_bar = Progressbar(self.win, orient = 'horizontal', length = 250, mode = 'determinate', style="red.Horizontal.TProgressbar")
		self.progress_bar.pack(pady = 1)

		# create runner button
		self.runner = Button(self.win, text = 'RUN', command = self.click_me, fg = '#cc3333', font = 'Calibri 13 bold', bg = 'white', height = 1, width = 23)
		self.runner.pack(ipadx = 5, ipady = 10, padx = 15, pady = 15, anchor = 'center')

		# create copyright details
		self.bottombar = Label(self.win, text = '', fg = 'gray13', font = 'Sans 9', bg = 'gray95', relief = FLAT, anchor = W)
		self.bottombar.config(height = 1)
		self.bottombar.pack(side = BOTTOM, fill = X)

		# create statusbar bar during running
		self.statusbar = Label(self.win, text = 'Please wait... This may take a while depending on the number of files selected.', fg = 'gray20', font = 'Calibri 11', bg = 'gray95',
							   relief = FLAT, anchor = W)
		self.statusbar.config(height = 1)

# ==================================================================
# Other Classes
# ==================================================================
# create an as-you-type suggestions for Combobox
class AutoCompleteCombobox(Combobox):
	"""
	Credits goes to Mitja Martini and Russell Adams
	Source: https://ttkwidgets.readthedocs.io/en/latest/_modules/ttkwidgets/autocomplete/autocompletecombobox.html
	"""

	def __init__(self, master = None, completevalues = None, **kwargs):
		"""
		:param master: master widget
		:type master: widget
		:param completevalues: autocompletion values
		:type completevalues: list
		:param kwargs: keyword arguments passed to the :class:`ttk.Combobox` initializer
		"""
		Combobox.__init__(self, master, values = completevalues, **kwargs)
		self._completion_list = completevalues
		if isinstance(completevalues, list):
			self.set_completion_list(completevalues)
		self._hits = []
		self._hit_index = 0
		self.position = 0
		# navigate on keypress in the dropdown:
		# code taken from https://wiki.tcl-lang.org/page/ttk%3A%3Acombobox by Pawel Salawa, copyright 2011
		self.tk.eval("""
		proc ComboListKeyPressed {w key} {
        if {[string length $key] > 1 && [string tolower $key] != $key} {
                return
        }

        set cb [winfo parent [winfo toplevel $w]]
        set text [string map [list {[} {\[} {]} {\]}] $key]
        if {[string equal $text ""]} {
                return
        }

        set values [$cb cget -values]
        set x [lsearch -glob -nocase $values $text*]
        if {$x < 0} {
                return
        }

        set current [$w curselection]
        if {$current == $x && [string match -nocase $text* [lindex $values [expr {$x+1}]]]} {
                incr x
        }

        $w selection clear 0 end
        $w selection set $x
        $w activate $x
        $w see $x
		}

		set popdown [ttk::combobox::PopdownWindow %s]
		bind $popdown.f.l <KeyPress> [list ComboListKeyPressed %%W %%K]
		""" % (self))

	def set_completion_list(self, completion_list):
		"""
		Use the completion list as drop down selection menu, arrows move through menu.

		:param completion_list: completion values
		:type completion_list: list
		"""
		self._completion_list = sorted(completion_list, key = str.lower)  # Work with a sorted list
		self.configure(values = completion_list)
		self._hits = []
		self._hit_index = 0
		self.position = 0
		self.bind('<KeyRelease>', self.handle_keyrelease)
		self['values'] = self._completion_list  # Setup our popup menu

	def autocomplete(self, delta = 0):
		"""
		Autocomplete the Combobox.

		:param delta: 0, 1 or -1: how to cycle through possible hits
		:type delta: int
		"""
		if delta:  # need to delete selection otherwise we would fix the current position
			self.delete(self.position, END)
		else:  # set position to end so selection starts where textentry ended
			self.position = len(self.get())
		# collect hits
		_hits = []
		for element in self._completion_list:
			if element.lower().startswith(self.get().lower()):  # Match case insensitively
				_hits.append(element)
		# if we have a new hit list, keep this in mind
		if _hits != self._hits:
			self._hit_index = 0
			self._hits = _hits
		# only allow cycling if we are in a known hit list
		if _hits == self._hits and self._hits:
			self._hit_index = (self._hit_index + delta) % len(self._hits)
		# now finally perform the auto completion
		if self._hits:
			self.delete(0, END)
			self.insert(0, self._hits[self._hit_index])
			self.select_range(self.position, END)

	def handle_keyrelease(self, event):
		"""
		Event handler for the keyrelease event on this widget.

		:param event: Tkinter event
		"""
		if event.keysym == 'BackSpace':
			self.delete(self.index(INSERT), END)
			self.position = self.index(END)
		if event.keysym == 'Left':
			if self.position < self.index(END):  # delete the selection
				self.delete(self.position, END)
			else:
				self.position -= 1  # delete one character
				self.delete(self.position, END)
		if event.keysym == 'Right':
			self.position = self.index(END)  # go to end (no selection)
		if event.keysym == 'Return':
			self.handle_return(None)
			return
		if len(event.keysym) == 1:
			self.autocomplete()

		# No need for up/down, we'll jump to the popup
		# list at the position of the autocompletion

	def handle_return(self, event):
		"""
		Function to bind to the Enter/Return key so if Enter is pressed the selection is cleared

		:param event: Tkinter event
		"""
		self.icursor(END)
		self.selection_clear()

	def config(self, **kwargs):
		"""Alias for configure"""
		self.configure(**kwargs)

	def configure(self, **kwargs):
		"""Configure widget specific keyword arguments in addition to :class:`ttk.Combobox` keyword arguments."""
		if 'completevalues' in kwargs:
			self.set_completion_list(kwargs.pop('completevalues'))
		return Combobox.configure(self, **kwargs)

	def cget(self, key):
		"""Return value for widget specific keyword arguments"""
		if key == 'completevalues':
			return self._completion_list
		return Combobox.cget(self, key)

	def keys(self):
		"""Return a list of all resource names of this widget."""
		keys = Combobox.keys(self)
		keys.append('completevalues')
		return keys

	def __setitem__(self, key, value):
		self.configure(**{key:value})

	def __getitem__(self, item):
		return self.cget(item)

# ==================================================================
# GUI
# ==================================================================
# start gui
efour_ts = E4_TimeStamper()
efour_ts.win.mainloop()
os.chdir('/Users/imranture/OneDrive - RMIT University/project/Unzip')
